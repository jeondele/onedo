package com.one.doo.qna.domain;

public class Qna {

}
