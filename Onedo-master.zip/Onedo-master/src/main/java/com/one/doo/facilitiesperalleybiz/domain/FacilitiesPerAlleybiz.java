package com.one.doo.facilitiesperalleybiz.domain;

/**
 * @author 박호준
 *
 */
public class FacilitiesPerAlleybiz {
	private String FPD_DATE;     
	private int AlleybizCode;
	private int Facility_count;
	private double Offices_count;               
	private double Bank_count;
    private double Ghospital_count;
    private double Hospital_count;
    private double Pharm_count;
    private double Kinder_count;
    private double Ele_count;
    private double Mid_count;
    private double High_count;
    private double Uni_count;
    private double Depart_count;               
    private double Market_count;
    private double Theater_count;
    private double Room_count;
    private double Air_count;
    private double Rail_count;
    private double Terminal_count;
    private double Subway_count;
    private double Bus_count;
    private double TotalHousehold;
}
